
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import minidb.xmlParser.*;
import constants.*;

/*
To do
- Comment the code
- Table Layout for the data.
- usage of threads
*/

/**
 * Javadoc comments. All are static methods because we are not creating any
 * object of this class.
 *
 * @author Chanakya
 */
public class cli {

    /**
     * The Registry File is a XML file which contains the information about the all
     * the databases created. It acts as a pointer to the Database File. So, We
     * instantly load the registry file.
     */
    public static RegistryFactory registryFactory;
    public static RegistryFile registry;

    /**
     * This attribute is for storing the DatabaseFile instance. Which is assigned
     * when the user calls the command "use". if the user does not call the command
     * "use" then the We show a error message.
     */
    public static DatabaseFile CurrentDb;

    public static void main(String[] args) {
        System.out.println(constants.HEADING);

        registry = new RegistryFactory(constants.DATA_XML_PATH).getFile();
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.print(constants.CMD_PREFIX);

            String currentCmd = input.nextLine();

            // break if user wants to exit
            if (currentCmd.equals("exit;")) {
                break;
            }
            long startTime = System.nanoTime();
            Inputs inputs = new Inputs();
            inputs.cliInputs(currentCmd);
            long endTime = System.nanoTime();

            long exeTime = (endTime - startTime) / 1000000;
            System.out.println("\nExecution Time: " + exeTime + "ms");
        }

        input.close();
    }

}

class Inputs {
    private ICommands command;
    ArrayList<String> cliArgs=new ArrayList<>(Arrays.asList("New","Use","List","Help","Info","Schema","Read","Drop","Update"));
    ArrayList<ICommands>cliObjects=new ArrayList<>(Arrays.asList(new New(),new Use(), new List(), new Help(), new Info(), new Schema(), new Read(), new Drop(), new Update()));
    private String[] cmdArgs;

    public void cliInputs(String input) {
       this.cmdArgs = input.split(" ");
       try{
           this.setCommand();
       }catch(Exception e){
           e.printStackTrace();
       }
    }

    public void setCommand() throws Exception{
            for(int i=0;i<cliArgs.size();i++) {
                if (cliArgs.get(i).toLowerCase().compareTo(cmdArgs[0])==0) {
                    ICommands command = cliObjects.get(i);
                    this.command=command;
                    break;
                }
            }
            this.command.execute(cmdArgs);
        }





}

interface ICommands{
    default void print(String x) {
        System.out.println(x);
    }

    default void execute(String cmdArgs[]){
        print("UNKNOWN COMMAND: " + cmdArgs[0] + "\nType `help;` for commands list");
    }
}


class New implements ICommands {
    public void execute(String cmdArgs[]) {
        cli.registry.createNewDatabase(cmdArgs[1]);
    }
}

class Use implements ICommands {
    public void execute(String cmdArgs[]) {
        System.out.println("executing use");
        String path = cli.registry.getDatabasePath(cmdArgs[1], false);

        if (path != null) {
            cli.CurrentDb = new DatabaseFile(path);
            cli.CurrentDb.EditMode();
            print("Successfully loaded Database named: " + cmdArgs[1]);
        } else {
            print("Database not found");
        }
    }
}

class List implements ICommands {
    public void execute(String cmdArgs[]) {
        cli.registry.listAllDatabases();
    }
}

class Help implements ICommands {
    public void execute(String cmdArgs[]) {
        print(constants.HELP_COMMANDS);
    }
}

class Info implements ICommands {
    public void execute(String cmdArgs[]) {

    }
}

class Schema implements ICommands {
    public void execute(String cmdArgs[]) {
        if (cli.CurrentDb != null) {
            String xy = cmdArgs[1];

            if (xy.equals("show")) {
                print(cli.CurrentDb.getSchema());
            } else {
                String[] schemaVals = xy.split(",");
                if (schemaVals.length > 1) {
                    cli.CurrentDb.createSchema(xy);
                } else {
                    print("There should be atleast 2 columns of data");
                }
            }

        } else {
            print(errors.NO_DATABASE_SELECTED);
        }
    }
}

class Add implements ICommands {
    public void execute(String cmdArgs[]) {
        if (cli.CurrentDb != null) {
            cli.CurrentDb.addData(cmdArgs[1]);
        } else {
            print(errors.NO_DATABASE_SELECTED);
        }
    }
}

class Read implements ICommands {
    public void execute(String cmdArgs[]) {
        if (cli.CurrentDb != null) {
            if (cmdArgs.length == 1) {
                cli.CurrentDb.readData();
            } else {
                cli.CurrentDb.readData(cmdArgs[1]);
            }
        } else {
            print(errors.NO_DATABASE_SELECTED);
        }
    }
}

class Drop implements ICommands {
    public void execute(String cmdArgs[]) {
        cli.registry.deleteDatabase(cmdArgs[1]);
    }
}


class Update implements ICommands {
    public void execute(String cmdArgs[]) {
        // TODO
        if (cli.CurrentDb != null) {
        }
    }
}

class Delete implements ICommands {
    public void execute(String cmdArgs[]) {
        if (cli.CurrentDb != null) {
            cli.CurrentDb.deleteData(cmdArgs[1]);
        } else {
            print(errors.NO_DATABASE_SELECTED);
        }
    }
}

class Default implements ICommands {
    public void execute(String cmdArgs[]) {
        print("UNKNOWN COMMAND: " + cmdArgs[0] + "\nType `help;` for commands list");
    }
}




// Commands that are available
// ✅ read
// ✅ read id=2
// read id=8..99

// ✅ add 04,cow,25

// ✅ delete id=2
// delete id=5..7

// ✅ schema id, name, age
// schema update id, name,age
// ✅ schema show

// The hardest one:
// update name='cow' where id=2

// Future:
// - import/export databases cmds