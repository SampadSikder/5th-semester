package constants;

public class errors {
    public static String NO_DATABASE_SELECTED = "You need to select a database first with `use` command";
}
