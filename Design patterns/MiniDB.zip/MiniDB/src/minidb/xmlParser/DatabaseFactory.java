package minidb.xmlParser;

public class DatabaseFactory extends XMLFactory{

        String path;
        public DatabaseFactory(String path){
            this.path=path;
        }
        public DatabaseFile getFile(){
            return new DatabaseFile(this.path);
        }


}
