package minidb.xmlParser;

public class RegistryFactory extends XMLFactory {
    String path;
    public RegistryFactory(String path){
        this.path=path;
    }
    public RegistryFile getFile(){
        return new RegistryFile(this.path);
    }
}
