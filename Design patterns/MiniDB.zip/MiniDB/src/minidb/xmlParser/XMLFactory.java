package minidb.xmlParser;


public abstract class XMLFactory {
    public abstract XMLFiles getFile();
}